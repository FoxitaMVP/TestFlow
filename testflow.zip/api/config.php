<?php

return [
    'driver' => 'sqlite',
    'sqlite' => [
        'path' => __DIR__ . '/../database/testflow.local.db',
    ],
];
